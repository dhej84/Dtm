import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import http from 'http';

const BASE_URL = 'http://localhost:8080'; // Through NGINX reverse proxy on port 8080
const TMP_DIR = '/tmp/test_videos';

interface TestResult {
  scenario: string;
  expected: string;
  actualStatus: number;
  actualMessage: string;
  passed: boolean;
  duration?: number;
  details?: string;
}

const results: TestResult[] = [];

// Helper to make multipart POST request without third-party libraries
function uploadFile(
  endpoint: string,
  filePath: string,
  fieldName: string = 'video',
  token?: string
): Promise<{ status: number; body: any; raw: string }> {
  return new Promise((resolve, reject) => {
    const boundary = '----WebKitFormBoundary' + Math.random().toString(36).substring(2);
    const fileName = path.basename(filePath);
    const fileContent = fs.readFileSync(filePath);

    let mimeType = 'video/mp4';
    if (fileName.endsWith('.webm')) mimeType = 'video/webm';
    if (fileName.endsWith('.mov')) mimeType = 'video/quicktime';
    if (fileName.endsWith('.txt')) mimeType = 'text/plain';

    const header = Buffer.from(
      `--${boundary}\r\n` +
      `Content-Disposition: form-data; name="${fieldName}"; filename="${fileName}"\r\n` +
      `Content-Type: ${mimeType}\r\n\r\n`
    );
    const footer = Buffer.from(`\r\n--${boundary}--\r\n`);
    const payload = Buffer.concat([header, fileContent, footer]);

    const url = new URL(endpoint, BASE_URL);
    const headers: Record<string, string> = {
      'Content-Type': `multipart/form-data; boundary=${boundary}`,
      'Content-Length': payload.length.toString(),
    };
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const req = http.request(
      {
        hostname: url.hostname,
        port: url.port || 80,
        path: url.pathname,
        method: 'POST',
        headers,
        timeout: 30000,
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          let parsed: any = null;
          try {
            parsed = JSON.parse(data);
          } catch {
            parsed = data;
          }
          resolve({ status: res.statusCode || 0, body: parsed, raw: data });
        });
      }
    );

    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

// Helper to test range playback (HTTP 206)
function testPlayback(videoUrl: string): Promise<{ status: number; hasContentRange: boolean }> {
  return new Promise((resolve, reject) => {
    const url = new URL(videoUrl, BASE_URL);
    const req = http.request(
      {
        hostname: url.hostname,
        port: url.port || 80,
        path: url.pathname,
        method: 'GET',
        headers: {
          Range: 'bytes=0-1024',
        },
      },
      (res) => {
        let bytes = 0;
        res.on('data', (chunk) => (bytes += chunk.length));
        res.on('end', () => {
          resolve({
            status: res.statusCode || 0,
            hasContentRange: !!res.headers['content-range'],
          });
        });
      }
    );
    req.on('error', reject);
    req.end();
  });
}

// Helper to log in and get JWT token
async function loginUser(): Promise<string> {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify({
      email: 'varshithasundar07@gmail.com',
      password: 'password123',
    });
    const req = http.request(
      {
        hostname: 'localhost',
        port: 8080,
        path: '/api/v1/auth/login',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload).toString(),
        },
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          try {
            const body = JSON.parse(data);
            const token = body.data?.token || body.token;
            if (!token) throw new Error('No token returned: ' + data);
            resolve(token);
          } catch (e) {
            reject(e);
          }
        });
      }
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

async function run() {
  console.log('===========================================================');
  console.log('       SKILLSWAP VIDEO UPLOAD & DURATION TEST SUITE        ');
  console.log('===========================================================');

  if (!fs.existsSync(TMP_DIR)) {
    fs.mkdirSync(TMP_DIR, { recursive: true });
  }

  // 1. Authenticate
  console.log('\n[1/4] Authenticating with central backend...');
  const token = await loginUser();
  console.log('✓ Successfully authenticated! JWT Token acquired.');

  // 2. Synthesize test video clips
  console.log('\n[2/4] Generating test video files using ffmpeg...');

  const files = {
    vid30s: path.join(TMP_DIR, 'test_30s.mp4'),
    vid45s: path.join(TMP_DIR, 'test_45s.webm'),
    vid60s: path.join(TMP_DIR, 'test_60s.mov'),
    vid90s: path.join(TMP_DIR, 'test_90s.mp4'),
    vid15s: path.join(TMP_DIR, 'test_15s_too_short.mp4'),
    vid120s: path.join(TMP_DIR, 'test_120s_too_long.mp4'),
    vidLarge45s: path.join(TMP_DIR, 'test_large_45s.mp4'),
    unsupportedTxt: path.join(TMP_DIR, 'fake_video.txt'),
    corruptedVid: path.join(TMP_DIR, 'corrupted_sample.mp4'),
  };

  if (!fs.existsSync(files.vid30s)) {
    console.log('  Generating 30s MP4 (boundary lower)...');
    execSync(`ffmpeg -y -f lavfi -i testsrc=duration=30:size=320x240:rate=10 -f lavfi -i sine=frequency=1000:duration=30 -c:v libx264 -pix_fmt yuv420p -c:a aac ${files.vid30s} -loglevel error`);
  }
  if (!fs.existsSync(files.vid45s)) {
    console.log('  Generating 45s WebM...');
    execSync(`ffmpeg -y -f lavfi -i testsrc=duration=45:size=320x240:rate=10 -f lavfi -i sine=frequency=800:duration=45 -c:v libvpx -c:a libvorbis ${files.vid45s} -loglevel error`);
  }
  if (!fs.existsSync(files.vid60s)) {
    console.log('  Generating 60s MOV...');
    execSync(`ffmpeg -y -f lavfi -i testsrc=duration=60:size=320x240:rate=10 -f lavfi -i sine=frequency=440:duration=60 -c:v libx264 -pix_fmt yuv420p -c:a aac ${files.vid60s} -loglevel error`);
  }
  if (!fs.existsSync(files.vid90s)) {
    console.log('  Generating 90s MP4 (boundary upper)...');
    execSync(`ffmpeg -y -f lavfi -i testsrc=duration=90:size=320x240:rate=10 -f lavfi -i sine=frequency=520:duration=90 -c:v libx264 -pix_fmt yuv420p -c:a aac ${files.vid90s} -loglevel error`);
  }
  if (!fs.existsSync(files.vid15s)) {
    console.log('  Generating 15s MP4 (< 30s too short)...');
    execSync(`ffmpeg -y -f lavfi -i testsrc=duration=15:size=320x240:rate=10 -c:v libx264 -pix_fmt yuv420p ${files.vid15s} -loglevel error`);
  }
  if (!fs.existsSync(files.vid120s)) {
    console.log('  Generating 120s MP4 (> 90s too long)...');
    execSync(`ffmpeg -y -f lavfi -i testsrc=duration=120:size=320x240:rate=5 -c:v libx264 -pix_fmt yuv420p ${files.vid120s} -loglevel error`);
  }
  if (!fs.existsSync(files.vidLarge45s)) {
    console.log('  Generating 45s high-bitrate large file (> 35MB)...');
    execSync(`ffmpeg -y -f lavfi -i testsrc=duration=45:size=1280x720:rate=30 -c:v libx264 -b:v 7M -maxrate 8M -bufsize 8M -pix_fmt yuv420p ${files.vidLarge45s} -loglevel error`);
  }

  // Plain text file disguised
  fs.writeFileSync(files.unsupportedTxt, 'This is a plain text file, not a video.');

  // Corrupted video file (invalid header/truncated bytes)
  const partial = fs.readFileSync(files.vid30s).subarray(0, 150);
  fs.writeFileSync(files.corruptedVid, Buffer.concat([partial, Buffer.from('DEADBEEFCORRUPTEDSTREAM')]));

  console.log('✓ All test assets synthesized.');

  // 3. Run upload tests
  console.log('\n[3/4] Running automated upload tests against backend API...');

  // Test 1: Exactly 30s video
  {
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.vid30s, 'video', token);
    const passed = res.status === 200 && res.body?.success === true;
    results.push({
      scenario: '1. Exactly 30-Second Video (Boundary Lower: 30s)',
      expected: 'HTTP 200 OK, valid duration recorded',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      duration: res.body?.data?.rawDurationSeconds,
      passed,
      details: res.body?.data?.videoUrl,
    });
  }

  // Test 2: 45s WebM video
  {
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.vid45s, 'video', token);
    const passed = res.status === 200 && res.body?.success === true;
    results.push({
      scenario: '2. 45-Second WebM Video (Standard Valid Range)',
      expected: 'HTTP 200 OK, WebM format supported',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      duration: res.body?.data?.rawDurationSeconds,
      passed,
      details: res.body?.data?.videoUrl,
    });
  }

  // Test 3: 60s MOV video
  {
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.vid60s, 'video', token);
    const passed = res.status === 200 && res.body?.success === true;
    results.push({
      scenario: '3. 60-Second MOV Video (QuickTime Container)',
      expected: 'HTTP 200 OK, MOV format supported',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      duration: res.body?.data?.rawDurationSeconds,
      passed,
      details: res.body?.data?.videoUrl,
    });
  }

  // Test 4: Exactly 90s video (Boundary upper)
  let lastUploadedUrl = '';
  {
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.vid90s, 'video', token);
    const passed = res.status === 200 && res.body?.success === true;
    if (passed) lastUploadedUrl = res.body?.data?.videoUrl;
    results.push({
      scenario: '4. Exactly 90-Second Video (Boundary Upper: 90s / 1m30s)',
      expected: 'HTTP 200 OK, duration validated & accepted',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      duration: res.body?.data?.rawDurationSeconds,
      passed,
      details: res.body?.data?.videoUrl,
    });
  }

  // Test 5: Video shorter than 30s (15s)
  {
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.vid15s, 'video', token);
    const passed = res.status === 400 && res.body?.code === 'VIDEO_TOO_SHORT';
    results.push({
      scenario: '5. Video Shorter than 30 Seconds (15s)',
      expected: 'HTTP 400 with VIDEO_TOO_SHORT error message',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      passed,
      details: `Reported duration: ${res.body?.duration}s`,
    });
  }

  // Test 6: Video longer than 90s (120s)
  {
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.vid120s, 'video', token);
    const passed = res.status === 400 && res.body?.code === 'VIDEO_TOO_LONG';
    results.push({
      scenario: '6. Video Longer than 90 Seconds (120s / 2m)',
      expected: 'HTTP 400 with VIDEO_TOO_LONG error message',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      passed,
      details: `Reported duration: ${res.body?.duration}s`,
    });
  }

  // Test 7: Large video file (> 35MB) within duration range
  {
    const stat = fs.statSync(files.vidLarge45s);
    const sizeMb = (stat.size / (1024 * 1024)).toFixed(1);
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.vidLarge45s, 'video', token);
    const passed = res.status === 200 && res.body?.success === true;
    results.push({
      scenario: `7. Large Video File (${sizeMb} MB) within allowed duration`,
      expected: 'HTTP 200 OK, NGINX 2GB limit permits smooth upload',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      duration: res.body?.data?.rawDurationSeconds,
      passed,
      details: `Size: ${sizeMb}MB`,
    });
  }

  // Test 8: Unsupported file format (.txt)
  {
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.unsupportedTxt, 'video', token);
    const passed = res.status === 400;
    results.push({
      scenario: '8. Unsupported File Format (Plain text file)',
      expected: 'HTTP 400 rejected as unsupported or non-video',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      passed,
    });
  }

  // Test 9: Corrupted video file (truncated/damaged stream)
  {
    const res = await uploadFile('/api/v1/uploads/lesson-video', files.corruptedVid, 'video', token);
    const passed = res.status === 400 && res.body?.code === 'INVALID_VIDEO_FILE';
    results.push({
      scenario: '9. Corrupted Video File (Damaged stream container)',
      expected: 'HTTP 400 with INVALID_VIDEO_FILE error message',
      actualStatus: res.status,
      actualMessage: res.body?.message || res.raw,
      passed,
    });
  }

  // Test 10: Video Playback & Range Requests (HTTP 206)
  if (lastUploadedUrl) {
    console.log('\n[4/4] Verifying Video Playback & HTTP 206 Partial Range Serving...');
    const playback = await testPlayback(lastUploadedUrl);
    const passed = playback.status === 206 && playback.hasContentRange;
    results.push({
      scenario: '10. HTML5 Playback & HTTP 206 Partial Content Stream',
      expected: 'HTTP 206 Partial Content with Content-Range header for smooth scrubbing',
      actualStatus: playback.status,
      actualMessage: `HTTP ${playback.status} (has Content-Range: ${playback.hasContentRange})`,
      passed,
      details: lastUploadedUrl,
    });
  }

  // Clean up temporary files
  try {
    fs.rmSync(TMP_DIR, { recursive: true, force: true });
  } catch {}

  // Print results summary
  console.log('\n===========================================================');
  console.log('                   VERIFICATION RESULTS                    ');
  console.log('===========================================================');
  let allPassed = true;
  for (const r of results) {
    const symbol = r.passed ? '✓ PASS' : '✗ FAIL';
    console.log(`[${symbol}] ${r.scenario}`);
    console.log(`       Status: ${r.actualStatus} | Expected: ${r.expected}`);
    console.log(`       Message: ${r.actualMessage}`);
    if (r.details) console.log(`       Details: ${r.details}`);
    if (!r.passed) allPassed = false;
  }
  console.log('===========================================================');
  if (allPassed) {
    console.log('🎉 ALL 10 VIDEO UPLOAD & DURATION TEST SCENARIOS PASSED!');
  } else {
    console.log('⚠️ Some test scenarios failed. Please check the logs above.');
    process.exit(1);
  }
}

run().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});

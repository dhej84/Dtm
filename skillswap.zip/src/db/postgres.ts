import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { PGlite } from '@electric-sql/pglite';
import pg from 'pg';

export const JWT_SECRET =
  process.env.JWT_SECRET || '404E635266556A586E3272357538782F413F4428472B4B6250645367566B5970';

// Global database reference
interface IDatabaseClient {
  query(sqlText: string, params?: any[]): Promise<{ rows: any[] }>;
  exec(sqlText: string): Promise<void>;
  close?(): Promise<void>;
}

let dbClient: IDatabaseClient | null = null;
let isInitialized = false;

// Determine storage path for persistent PostgreSQL WASM files
const dataDir = path.resolve(process.cwd(), 'uploads', 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}
const pgDataPath = path.join(dataDir, 'postgres_db');

/**
 * Get or initialize the PostgreSQL database connection.
 * Connects to Cloud SQL if SQL_HOST & SQL_USER are configured;
 * otherwise uses PGlite with persistent on-disk storage.
 */
export async function getDatabase(): Promise<IDatabaseClient> {
  if (dbClient) return dbClient;

  const sqlHost = process.env.SQL_HOST;
  const sqlUser = process.env.SQL_USER;
  const sqlPassword = process.env.SQL_PASSWORD;
  const sqlDbName = process.env.SQL_DB_NAME;

  if (sqlHost && sqlUser) {
    console.log(`[PostgreSQL] Connecting to remote PostgreSQL/Cloud SQL at ${sqlHost}...`);
    const pool = new pg.Pool({
      host: sqlHost,
      user: sqlUser,
      password: sqlPassword,
      database: sqlDbName,
      max: 10,
      connectionTimeoutMillis: 15000,
    });
    pool.on('error', (err) => {
      console.error('[PostgreSQL] Unexpected error on idle client:', err);
    });
    dbClient = {
      async query(sqlText: string, params?: any[]) {
        const res = await pool.query(sqlText, params);
        return { rows: res.rows };
      },
      async exec(sqlText: string) {
        await pool.query(sqlText);
      },
      async close() {
        await pool.end();
      },
    };
  } else {
    console.log(`[PostgreSQL] Initializing persistent PostgreSQL database at: ${pgDataPath}`);
    ensurePostgresDirIntegrity(pgDataPath);

    const createClient = (dir: string): { pglite: PGlite; client: IDatabaseClient } => {
      const pglite = new PGlite(dir);
      const client: IDatabaseClient = {
        async query(sqlText: string, params?: any[]) {
          const res = await pglite.query(sqlText, params);
          return { rows: res.rows || [] };
        },
        async exec(sqlText: string) {
          await pglite.exec(sqlText);
        },
        async close() {
          try {
            await pglite.close();
          } catch {
            // ignore
          }
        },
      };
      return { pglite, client };
    };

    let active = createClient(pgDataPath);
    dbClient = active.client;

    try {
      await initSchemaAndSeed(dbClient);
      isInitialized = true;
    } catch (schemaErr) {
      console.warn('[PostgreSQL] Database startup threw error, repairing directory structure and re-seeding from persistent storage:', schemaErr);
      try {
        await active.client.close?.();
      } catch {
        // ignore
      }
      try {
        fs.rmSync(pgDataPath, { recursive: true, force: true });
        fs.mkdirSync(pgDataPath, { recursive: true });
      } catch (rmErr) {
        console.warn('[PostgreSQL] Could not recreate directory:', rmErr);
      }
      active = createClient(pgDataPath);
      dbClient = active.client;
      await initSchemaAndSeed(dbClient);
      isInitialized = true;
    }

    // Clean exit handlers to avoid leaving postmaster.pid on termination
    const cleanExit = async () => {
      try {
        if (dbClient?.close) {
          await dbClient.close();
        }
      } catch {
        // ignore
      }
    };
    process.once('SIGINT', cleanExit);
    process.once('SIGTERM', cleanExit);
  }

  return dbClient;
}

/**
 * Ensures required directories and configuration files exist for PostgreSQL WASM
 */
function ensurePostgresDirIntegrity(dir: string) {
  try {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      return;
    }
    const pidFile = path.join(dir, 'postmaster.pid');
    if (fs.existsSync(pidFile)) {
      try {
        fs.unlinkSync(pidFile);
      } catch {}
    }
    if (fs.existsSync(path.join(dir, 'PG_VERSION'))) {
      const confFile = path.join(dir, 'postgresql.conf');
      if (!fs.existsSync(confFile)) {
        fs.writeFileSync(confFile, '');
      }
      const requiredSubdirs = [
        'pg_notify',
        'pg_tblspc',
        'pg_twophase',
        'pg_snapshots',
        'pg_stat',
        'pg_stat_tmp',
        'pg_commit_ts',
        'pg_wal',
        'pg_wal/archive_status',
        'pg_wal/summaries',
      ];
      for (const sub of requiredSubdirs) {
        const subPath = path.join(dir, sub);
        if (!fs.existsSync(subPath)) {
          fs.mkdirSync(subPath, { recursive: true });
        }
      }
    }
  } catch (err) {
    console.warn('[PostgreSQL] ensurePostgresDirIntegrity warning:', err);
  }
}

/**
 * Execute DDL schema migrations, seeds, and import existing accounts
 */
async function initSchemaAndSeed(db: IDatabaseClient) {
  console.log('[PostgreSQL] Initializing tables and schema...');

  // 1. Users Table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(36) PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      university VARCHAR(150) NOT NULL,
      department VARCHAR(150),
      year VARCHAR(50),
      is_verified BOOLEAN DEFAULT FALSE,
      avatar_url TEXT,
      role VARCHAR(50) DEFAULT 'ROLE_STUDENT',
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_users_university ON users(university);
  `);

  // 2. Profiles Table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS profiles (
      id VARCHAR(36) PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      bio TEXT,
      location VARCHAR(150),
      rank VARCHAR(100) DEFAULT 'Campus Member',
      member_since VARCHAR(50) DEFAULT 'Sep 2024',
      profile_visibility VARCHAR(50) DEFAULT 'PUBLIC',
      wallet_balance NUMERIC(10, 2) DEFAULT 10.00,
      hours_taught NUMERIC(10, 2) DEFAULT 0.00,
      hours_learned NUMERIC(10, 2) DEFAULT 0.00,
      peer_reputation NUMERIC(3, 2) DEFAULT 5.00,
      review_count INT DEFAULT 0,
      swap_fulfill_rate NUMERIC(5, 2) DEFAULT 100.00,
      verified_peers_only BOOLEAN DEFAULT TRUE,
      allow_direct_swaps BOOLEAN DEFAULT TRUE,
      public_learning_history BOOLEAN DEFAULT TRUE,
      mask_reviews BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // 3. Skills Catalog
  await db.exec(`
    CREATE TABLE IF NOT EXISTS skills (
      id VARCHAR(36) PRIMARY KEY,
      name VARCHAR(150) UNIQUE NOT NULL,
      category VARCHAR(100) NOT NULL,
      description TEXT,
      popular_level VARCHAR(50) DEFAULT 'Intermediate',
      popularity INT DEFAULT 0,
      students_count INT DEFAULT 0,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_skills_name ON skills(name);
  `);

  // 4. User Skills Table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS user_skills (
      id VARCHAR(36) PRIMARY KEY,
      user_id VARCHAR(36) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      skill_id VARCHAR(36) REFERENCES skills(id) ON DELETE SET NULL,
      name VARCHAR(150) NOT NULL,
      category VARCHAR(100) NOT NULL,
      skill_type VARCHAR(20) NOT NULL,
      skill_level VARCHAR(50) NOT NULL,
      target_level VARCHAR(50),
      proficiency_percent INT DEFAULT 0,
      hours_logged NUMERIC(10, 2) DEFAULT 0.00,
      hours_taught NUMERIC(10, 2) DEFAULT 0.00,
      hours_practiced NUMERIC(10, 2) DEFAULT 0.00,
      endorsements_count INT DEFAULT 0,
      reviews_count INT DEFAULT 0,
      partner_name VARCHAR(150),
      target_date VARCHAR(50),
      description TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT uq_user_skill UNIQUE (user_id, name, skill_type)
    );
    CREATE INDEX IF NOT EXISTS idx_user_skills_user_type ON user_skills(user_id, skill_type);
  `);

  // 5. Lessons Table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS lessons (
      id VARCHAR(36) PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      skill VARCHAR(150) NOT NULL,
      category VARCHAR(100) NOT NULL,
      description TEXT,
      skill_level VARCHAR(50) NOT NULL,
      format VARCHAR(50) NOT NULL DEFAULT 'Interactive Workshop',
      teacher_id VARCHAR(36) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      duration_minutes INT DEFAULT 60,
      credits_required NUMERIC(5, 2) DEFAULT 1.00,
      prerequisites TEXT,
      enrolled_students_count INT DEFAULT 0,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // 6. Lesson Videos & Video Storage Metadata (V7/V8 migrations)
  await db.exec(`
    ALTER TABLE lessons ADD COLUMN IF NOT EXISTS video_url TEXT;
    ALTER TABLE lessons ADD COLUMN IF NOT EXISTS video_filename VARCHAR(255);
    ALTER TABLE lessons ADD COLUMN IF NOT EXISTS video_duration VARCHAR(50);
    ALTER TABLE lessons ADD COLUMN IF NOT EXISTS video_file_size BIGINT;
    ALTER TABLE lessons ADD COLUMN IF NOT EXISTS video_mime_type VARCHAR(100);
    ALTER TABLE lessons ADD COLUMN IF NOT EXISTS video_storage_key VARCHAR(255);

    CREATE TABLE IF NOT EXISTS lesson_videos (
      id VARCHAR(64) PRIMARY KEY,
      lesson_id VARCHAR(64),
      original_filename VARCHAR(255) NOT NULL,
      mime_type VARCHAR(100) NOT NULL,
      file_size BIGINT NOT NULL,
      duration VARCHAR(50),
      duration_seconds NUMERIC(8, 2),
      storage_key VARCHAR(255) NOT NULL,
      storage_url TEXT NOT NULL,
      uploaded_by VARCHAR(64) REFERENCES users(id) ON DELETE SET NULL,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_lesson_videos_lesson ON lesson_videos(lesson_id);
    CREATE INDEX IF NOT EXISTS idx_lesson_videos_storage_key ON lesson_videos(storage_key);
  `);

  // Seed default skills
  await db.exec(`
    INSERT INTO skills (id, name, category, description, popular_level, popularity, students_count)
    VALUES
    ('skill-1', 'Distributed Systems', 'Computer Science', 'Raft consensus, Paxos, distributed storage, and microservices.', 'Advanced', 94, 18),
    ('skill-2', 'Applied Machine Learning', 'Computer Science', 'PyTorch deep neural nets, CNNs, transformers, and model evaluation.', 'Intermediate', 88, 24),
    ('skill-3', 'UX/UI Design Systems', 'Design & Arts', 'Figma auto-layout, token design systems, accessible typography.', 'Intermediate', 76, 15),
    ('skill-4', 'Organic Chemistry', 'Natural Sciences', 'Reaction mechanisms, retrosynthesis, NMR spectroscopy.', 'Intermediate', 82, 19),
    ('skill-5', 'Macroeconomics & Game Theory', 'Economics & Business', 'Nash equilibria, signaling games, monetary policy.', 'Intermediate', 65, 12),
    ('skill-6', 'Rust Systems Programming', 'Computer Science', 'Borrow checker, memory safety, async Tokio, and WebAssembly.', 'Advanced', 91, 14),
    ('skill-7', 'Statistical Causal Inference', 'Mathematics & Stats', 'Potential outcomes, instrumental variables, DAGs.', 'Advanced', 72, 11),
    ('skill-8', 'Biomaterials Engineering', 'Engineering', 'Hydrogels, tissue scaffolds, biocompatibility testing.', 'Mastery', 59, 9)
    ON CONFLICT (id) DO NOTHING;
  `);

  // Seed demo student users with BCrypt hash for 'password123'
  const defaultBcryptHash = bcrypt.hashSync('password123', 10);
  const demoUsers = [
    {
      id: 'user-1',
      name: 'Alex Rivera',
      email: 'alex.rivera@cs.stanford.edu',
      university: 'Stanford University',
      department: 'Computer Science & Systems',
      year: 'Senior',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    },
    {
      id: 'user-2',
      name: 'Elena Rostova',
      email: 'elena.rostova@oxford.edu',
      university: 'Oxford University',
      department: 'Biochemistry & Molecular Biology',
      year: 'Graduate',
      avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    },
    {
      id: 'user-3',
      name: 'Marcus Vance',
      email: 'marcus.vance@mit.edu',
      university: 'MIT',
      department: 'Human-Computer Interaction',
      year: 'Junior',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    },
    {
      id: 'user-4',
      name: 'David Kim',
      email: 'david.kim@stanford.edu',
      university: 'Stanford University',
      department: 'Electrical Engineering & AI',
      year: 'PhD Candidate',
      avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    },
    {
      id: 'user-5',
      name: 'Priya Patel',
      email: 'priya.patel@cambridge.edu',
      university: 'University of Cambridge',
      department: 'Economics & Public Policy',
      year: 'Senior',
      avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
    },
  ];

  for (const du of demoUsers) {
    await db.query(
      `INSERT INTO users (id, name, email, password_hash, university, department, year, is_verified, avatar_url, role)
       VALUES ($1, $2, $3, $4, $5, $6, $7, true, $8, 'ROLE_STUDENT')
       ON CONFLICT (email) DO NOTHING`,
      [du.id, du.name, du.email, defaultBcryptHash, du.university, du.department, du.year, du.avatarUrl]
    );

    await db.query(
      `INSERT INTO profiles (id, bio, location, rank, member_since, wallet_balance, hours_taught, hours_learned, peer_reputation, review_count, swap_fulfill_rate)
       VALUES ($1, $2, $3, 'Peer Fellow', 'Sep 2023', 15.00, 20.00, 10.00, 4.95, 12, 99.00)
       ON CONFLICT (id) DO NOTHING`,
      [du.id, `Active peer instructor at ${du.university}.`, `${du.university}`]
    );
  }

  // 6. Migrate and restore all existing accounts from JSON storage into PostgreSQL
  await importExistingAccounts(db, defaultBcryptHash);

  console.log('[PostgreSQL] Database initialization and user migration completed.');
}

/**
 * Import and preserve existing accounts from uploads/data/users.json and src/data/registeredUsers.json
 */
async function importExistingAccounts(db: IDatabaseClient, defaultBcryptHash: string) {
  const jsonSources = [
    path.resolve(process.cwd(), 'uploads', 'data', 'users.json'),
    path.resolve(process.cwd(), 'src', 'data', 'registeredUsers.json'),
  ];

  const processedEmails = new Set<string>();

  for (const src of jsonSources) {
    if (!fs.existsSync(src)) continue;
    try {
      const raw = fs.readFileSync(src, 'utf8');
      const usersList: any[] = JSON.parse(raw);
      if (!Array.isArray(usersList)) continue;

      for (const u of usersList) {
        if (!u || !u.email) continue;
        const cleanEmail = u.email.trim().toLowerCase();
        if (processedEmails.has(cleanEmail)) continue;
        processedEmails.add(cleanEmail);

        // Check if user already exists in PostgreSQL
        const existing = await db.query('SELECT id, password_hash FROM users WHERE LOWER(email) = $1', [cleanEmail]);

        let finalPasswordHash = defaultBcryptHash;
        if (u.password) {
          finalPasswordHash = bcrypt.hashSync(u.password, 10);
        } else if (u.passwordHash && u.passwordHash.startsWith('$2')) {
          finalPasswordHash = u.passwordHash;
        } else {
          // If password was password123 (e.g. varshitha)
          finalPasswordHash = bcrypt.hashSync('password123', 10);
        }

        const userId = u.id || `user-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
        const name = u.name || 'Student';
        const university = u.university || 'UC Berkeley';
        const department = u.department || 'Computer Science';
        const year = u.year || "'25";
        const isVerified = u.isVerified !== undefined ? u.isVerified : true;
        const avatarUrl =
          u.avatarUrl ||
          `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`;
        const role = u.role || 'ROLE_STUDENT';

        if (existing.rows.length === 0) {
          // Insert user
          await db.query(
            `INSERT INTO users (id, name, email, password_hash, university, department, year, is_verified, avatar_url, role)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
             ON CONFLICT (email) DO NOTHING`,
            [userId, name, cleanEmail, finalPasswordHash, university, department, year, isVerified, avatarUrl, role]
          );

          // Insert profile
          await db.query(
            `INSERT INTO profiles (id, bio, location, rank, member_since, wallet_balance, hours_taught, hours_learned, peer_reputation, review_count, swap_fulfill_rate)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
             ON CONFLICT (id) DO NOTHING`,
            [
              userId,
              u.bio || `Active SkillSwap peer learner and tutor in ${department}.`,
              u.location || `${university}, CA`,
              u.rank || 'Active Tutor',
              u.memberSince || 'Oct 2026',
              typeof u.walletBalance === 'number' ? u.walletBalance : 10.0,
              typeof u.hoursTaught === 'number' ? u.hoursTaught : 0.0,
              typeof u.hoursLearned === 'number' ? u.hoursLearned : 0.0,
              typeof u.peerReputation === 'number' ? u.peerReputation : 5.0,
              typeof u.reviewCount === 'number' ? u.reviewCount : 0,
              typeof u.swapFulfillRate === 'number' ? u.swapFulfillRate : 100.0,
            ]
          );

          // Insert teaching skills
          if (Array.isArray(u.teachingSkills)) {
            for (const s of u.teachingSkills) {
              if (!s || !s.name) continue;
              await db.query(
                `INSERT INTO user_skills (id, user_id, name, category, skill_type, skill_level, proficiency_percent, endorsements_count, reviews_count, description)
                 VALUES ($1, $2, $3, $4, 'TEACH', $5, $6, $7, $8, $9)
                 ON CONFLICT (user_id, name, skill_type) DO NOTHING`,
                [
                  s.id || `ts-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                  userId,
                  s.name,
                  s.category || 'General',
                  s.level || 'Mastery',
                  s.proficiencyPercent || 80,
                  s.endorsementsCount || 1,
                  s.reviewsCount || 0,
                  s.description || `Verified peer knowledge in ${s.name}.`,
                ]
              );
            }
          }

          // Insert learning skills
          if (Array.isArray(u.learningSkills)) {
            for (const s of u.learningSkills) {
              if (!s || !s.name) continue;
              await db.query(
                `INSERT INTO user_skills (id, user_id, name, category, skill_type, skill_level, target_level, proficiency_percent, partner_name)
                 VALUES ($1, $2, $3, $4, 'LEARN', $5, $6, $7, $8)
                 ON CONFLICT (user_id, name, skill_type) DO NOTHING`,
                [
                  s.id || `ls-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
                  userId,
                  s.name,
                  s.category || 'General',
                  s.currentLevel || 'Beginner',
                  s.targetLevel || 'Advanced',
                  s.progressPercent || 15,
                  s.partnerName || 'Seeking Mentor',
                ]
              );
            }
          }
        }
      }
    } catch (e) {
      console.warn(`[PostgreSQL] Error importing accounts from ${src}:`, e);
    }
  }
}

/**
 * Find user by email (case-insensitive and trimmed)
 */
export async function findUserByEmail(email: string): Promise<any | null> {
  const db = await getDatabase();
  const cleanEmail = email.trim().toLowerCase();

  const userRes = await db.query(
    `SELECT u.*, p.bio, p.location, p.rank, p.member_since, p.wallet_balance,
            p.hours_taught, p.hours_learned, p.peer_reputation, p.review_count,
            p.swap_fulfill_rate, p.verified_peers_only, p.allow_direct_swaps,
            p.public_learning_history, p.mask_reviews
     FROM users u
     LEFT JOIN profiles p ON u.id = p.id
     WHERE LOWER(TRIM(u.email)) = $1`,
    [cleanEmail]
  );

  if (userRes.rows.length === 0) return null;
  const raw = userRes.rows[0];

  return formatUserWithSkills(db, raw);
}

/**
 * Find user by email, ID, full name, or username handle in PostgreSQL
 */
export async function findUserByIdentifier(identifier: string): Promise<any | null> {
  const db = await getDatabase();
  const clean = identifier.trim().toLowerCase();
  if (!clean) return null;

  // 1. Direct email or ID match
  const userRes = await db.query(
    `SELECT u.*, p.bio, p.location, p.rank, p.member_since, p.wallet_balance,
            p.hours_taught, p.hours_learned, p.peer_reputation, p.review_count,
            p.swap_fulfill_rate, p.verified_peers_only, p.allow_direct_swaps,
            p.public_learning_history, p.mask_reviews
     FROM users u
     LEFT JOIN profiles p ON u.id = p.id
     WHERE LOWER(TRIM(u.email)) = $1 OR LOWER(TRIM(u.id)) = $1
     LIMIT 1`,
    [clean]
  );

  if (userRes.rows.length > 0) {
    return formatUserWithSkills(db, userRes.rows[0]);
  }

  // 2. Name or username prefix match
  const fallbackRes = await db.query(
    `SELECT u.*, p.bio, p.location, p.rank, p.member_since, p.wallet_balance,
            p.hours_taught, p.hours_learned, p.peer_reputation, p.review_count,
            p.swap_fulfill_rate, p.verified_peers_only, p.allow_direct_swaps,
            p.public_learning_history, p.mask_reviews
     FROM users u
     LEFT JOIN profiles p ON u.id = p.id
     WHERE LOWER(TRIM(u.name)) = $1
        OR LOWER(TRIM(SPLIT_PART(u.email, '@', 1))) = $1
     LIMIT 1`,
    [clean]
  );

  if (fallbackRes.rows.length > 0) {
    return formatUserWithSkills(db, fallbackRes.rows[0]);
  }

  return null;
}

/**
 * Find user by unique ID
 */
export async function findUserById(id: string): Promise<any | null> {
  const db = await getDatabase();

  const userRes = await db.query(
    `SELECT u.*, p.bio, p.location, p.rank, p.member_since, p.wallet_balance,
            p.hours_taught, p.hours_learned, p.peer_reputation, p.review_count,
            p.swap_fulfill_rate, p.verified_peers_only, p.allow_direct_swaps,
            p.public_learning_history, p.mask_reviews
     FROM users u
     LEFT JOIN profiles p ON u.id = p.id
     WHERE u.id = $1`,
    [id]
  );

  if (userRes.rows.length === 0) return null;
  const raw = userRes.rows[0];

  return formatUserWithSkills(db, raw);
}

/**
 * Check if an email is already registered (case-insensitive)
 */
export async function checkEmailExists(email: string): Promise<boolean> {
  const db = await getDatabase();
  const res = await db.query('SELECT id FROM users WHERE LOWER(email) = $1', [email.trim().toLowerCase()]);
  return res.rows.length > 0;
}

/**
 * Register a new user permanently into PostgreSQL
 */
export async function registerUserInDb(payload: {
  name: string;
  email: string;
  password: string;
  university: string;
  department?: string;
  year?: string;
  teachSkillName?: string;
  teachSkillLevel?: string;
  learnSkillName?: string;
}): Promise<any> {
  const db = await getDatabase();
  const cleanEmail = payload.email.trim().toLowerCase();

  // 1. Enforce unique email check
  const alreadyExists = await checkEmailExists(cleanEmail);
  if (alreadyExists) {
    const error: any = new Error(`An account with email ${cleanEmail} already exists`);
    error.status = 409;
    error.code = 'DUPLICATE_EMAIL';
    throw error;
  }

  // 2. Generate unique user ID and hash password with BCrypt
  const userId = `user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const passwordHash = bcrypt.hashSync(payload.password, 10);
  const isVerified = cleanEmail.endsWith('.edu') || cleanEmail.endsWith('.ac.uk');
  const role = 'ROLE_STUDENT';
  const name = payload.name.trim();
  const university = payload.university.trim();
  const department = (payload.department || 'Student').trim();
  const year = (payload.year || "'26").trim();
  const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`;

  // 3. Insert into users table
  await db.query(
    `INSERT INTO users (id, name, email, password_hash, university, department, year, is_verified, avatar_url, role)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [userId, name, cleanEmail, passwordHash, university, department, year, isVerified, avatarUrl, role]
  );

  // 4. Insert into profiles table
  await db.query(
    `INSERT INTO profiles (id, bio, location, rank, member_since, wallet_balance, hours_taught, hours_learned, peer_reputation, review_count, swap_fulfill_rate)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
    [
      userId,
      `Student at ${university} active in peer skill exchange.`,
      `${university}, CA`,
      'Campus Member',
      'Oct 2026',
      10.0,
      0.0,
      0.0,
      5.0,
      0,
      100.0,
    ]
  );

  // 5. Insert teaching skill if provided
  if (payload.teachSkillName && payload.teachSkillName.trim()) {
    const tsName = payload.teachSkillName.trim();
    const tsLevel = payload.teachSkillLevel || 'Intermediate';
    await db.query(
      `INSERT INTO user_skills (id, user_id, name, category, skill_type, skill_level, proficiency_percent, endorsements_count, description)
       VALUES ($1, $2, $3, $4, 'TEACH', $5, 80, 1, $6)`,
      [
        `ts-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        userId,
        tsName,
        'General',
        tsLevel,
        `Verified peer knowledge in ${tsName}.`,
      ]
    );
  }

  // 6. Insert learning skill if provided
  if (payload.learnSkillName && payload.learnSkillName.trim()) {
    const lsName = payload.learnSkillName.trim();
    await db.query(
      `INSERT INTO user_skills (id, user_id, name, category, skill_type, skill_level, target_level, proficiency_percent, partner_name)
       VALUES ($1, $2, $3, $4, 'LEARN', 'Beginner', 'Advanced', 15, 'Seeking Mentor')`,
      [`ls-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`, userId, lsName, 'General']
    );
  }

  // 7. Retrieve the newly created complete user record from PostgreSQL
  const fullUser = await findUserById(userId);

  // 8. Sync backup JSON file so existing external utilities stay in sync
  syncJsonBackup(fullUser);

  return fullUser;
}

/**
 * Verify candidate password against stored BCrypt hash with backwards-compatible upgrade
 */
export async function verifyUserPassword(candidatePassword: string, user: any): Promise<boolean> {
  if (!user) return false;
  const candidate = typeof candidatePassword === 'string' ? candidatePassword : '';
  const trimmed = candidate.trim();

  // 1. Direct BCrypt check
  if (user.password_hash && (user.password_hash.startsWith('$2a$') || user.password_hash.startsWith('$2b$'))) {
    if (bcrypt.compareSync(candidate, user.password_hash) || bcrypt.compareSync(trimmed, user.password_hash)) {
      return true;
    }
  }

  // 2. Backward compatibility: if plain password matches, upgrade to BCrypt in PostgreSQL
  if (user.password && (user.password === candidate || user.password === trimmed)) {
    const newHash = bcrypt.hashSync(candidate, 10);
    const db = await getDatabase();
    await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, user.id]);
    user.password_hash = newHash;
    return true;
  }

  // 3. Backward compatibility: legacy PBKDF2 hash upgrade
  if (user.password_hash && user.password_hash.includes(':')) {
    const crypto = await import('crypto');
    const [salt, hash] = user.password_hash.split(':');
    if (salt && hash) {
      const candidateHash = crypto.pbkdf2Sync(candidate, salt, 1000, 64, 'sha512').toString('hex');
      const trimmedHash = crypto.pbkdf2Sync(trimmed, salt, 1000, 64, 'sha512').toString('hex');
      if (candidateHash === hash || trimmedHash === hash) {
        // Upgrade to BCrypt in PostgreSQL
        const newHash = bcrypt.hashSync(candidate, 10);
        const db = await getDatabase();
        await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, user.id]);
        user.password_hash = newHash;
        return true;
      }
    }
  }

  // 4. Default accounts password fallback for 'password123'
  if (candidate === 'password123' || trimmed === 'password123') {
    if (!user.password_hash || user.password_hash === 'none') {
      const newHash = bcrypt.hashSync('password123', 10);
      const db = await getDatabase();
      await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, user.id]);
      user.password_hash = newHash;
      return true;
    }
  }

  return false;
}

/**
 * Generate cryptographic JWT access token (24-hour expiration)
 */
export function generateJwtToken(user: any): string {
  const payload = {
    sub: user.email,
    userId: user.id,
    email: user.email,
    role: user.role || 'ROLE_STUDENT',
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
}

/**
 * Validate and decode JWT token
 */
export function verifyJwtToken(token: string): { userId: string; email: string; role?: string } | null {
  try {
    const decoded: any = jwt.verify(token, JWT_SECRET);
    if (decoded && (decoded.userId || decoded.sub)) {
      return {
        userId: decoded.userId || decoded.id,
        email: decoded.email || decoded.sub,
        role: decoded.role,
      };
    }
  } catch {
    // Check fallback for format `jwt-token-${userId}-${timestamp}`
    if (token.startsWith('jwt-token-')) {
      const parts = token.split('-');
      if (parts.length >= 3) {
        const idPart = parts.slice(2, parts.length - 1).join('-');
        return { userId: idPart, email: '' };
      }
    }
  }
  return null;
}

/**
 * Retrieve all users formatted for directory and search
 */
export async function getAllUsersFromDb(): Promise<any[]> {
  const db = await getDatabase();
  const res = await db.query(
    `SELECT u.*, p.bio, p.location, p.rank, p.member_since, p.wallet_balance,
            p.hours_taught, p.hours_learned, p.peer_reputation, p.review_count,
            p.swap_fulfill_rate, p.verified_peers_only, p.allow_direct_swaps,
            p.public_learning_history, p.mask_reviews
     FROM users u
     LEFT JOIN profiles p ON u.id = p.id
     ORDER BY u.created_at ASC`
  );

  const skillsRes = await db.query('SELECT * FROM user_skills');
  const skillsByUser: Record<string, { teaching: any[]; learning: any[] }> = {};

  for (const s of skillsRes.rows) {
    if (!skillsByUser[s.user_id]) {
      skillsByUser[s.user_id] = { teaching: [], learning: [] };
    }
    if (s.skill_type === 'TEACH') {
      skillsByUser[s.user_id].teaching.push({
        id: s.id,
        name: s.name,
        category: s.category,
        level: s.skill_level,
        proficiencyPercent: s.proficiency_percent || 80,
        hoursTaught: Number(s.hours_taught || 0),
        reviewsCount: s.reviews_count || 0,
        endorsementsCount: s.endorsements_count || 1,
        description: s.description || `Peer knowledge in ${s.name}`,
      });
    } else {
      skillsByUser[s.user_id].learning.push({
        id: s.id,
        name: s.name,
        category: s.category,
        currentLevel: s.skill_level,
        targetLevel: s.target_level || 'Advanced',
        progressPercent: s.proficiency_percent || 15,
        hoursPracticed: Number(s.hours_practiced || 0),
        partnerName: s.partner_name || 'Seeking Mentor',
      });
    }
  }

  return res.rows.map((r) => {
    const userSkills = skillsByUser[r.id] || { teaching: [], learning: [] };
    return formatUserDto(r, userSkills.teaching, userSkills.learning);
  });
}

/**
 * Helper to format user with skills
 */
async function formatUserWithSkills(db: IDatabaseClient, raw: any) {
  const skillsRes = await db.query('SELECT * FROM user_skills WHERE user_id = $1', [raw.id]);
  const teachingSkills: any[] = [];
  const learningSkills: any[] = [];

  for (const s of skillsRes.rows) {
    if (s.skill_type === 'TEACH') {
      teachingSkills.push({
        id: s.id,
        name: s.name,
        category: s.category,
        level: s.skill_level,
        proficiencyPercent: s.proficiency_percent || 80,
        hoursTaught: Number(s.hours_taught || 0),
        reviewsCount: s.reviews_count || 0,
        endorsementsCount: s.endorsements_count || 1,
        description: s.description || `Verified peer knowledge in ${s.name}.`,
      });
    } else {
      learningSkills.push({
        id: s.id,
        name: s.name,
        category: s.category,
        currentLevel: s.skill_level,
        targetLevel: s.target_level || 'Advanced',
        progressPercent: s.proficiency_percent || 15,
        hoursPracticed: Number(s.hours_practiced || 0),
        partnerName: s.partner_name || 'Seeking Mentor',
      });
    }
  }

  return formatUserDto(raw, teachingSkills, learningSkills);
}

function formatUserDto(raw: any, teachingSkills: any[], learningSkills: any[]) {
  const nameSlug = (raw.name || 'student')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
  const cleanId = (raw.id || '').replace(/^user-/, '').replace(/[^a-z0-9]/g, '');
  const suffix = cleanId.substring(0, 4) || 'camp';
  const publicProfileId = `${nameSlug}-${suffix}`;

  return {
    id: raw.id,
    name: raw.name,
    email: raw.email,
    password_hash: raw.password_hash,
    passwordHash: raw.password_hash,
    university: raw.university,
    department: raw.department || 'Student',
    year: raw.year || "'26",
    isVerified: raw.is_verified,
    avatarUrl: raw.avatar_url,
    role: raw.role || 'ROLE_STUDENT',
    bio: raw.bio || `Active SkillSwap peer learner and tutor at ${raw.university}.`,
    location: raw.location || `${raw.university}, CA`,
    rank: raw.rank || 'Campus Member',
    memberSince: raw.member_since || 'Oct 2026',
    walletBalance: typeof raw.wallet_balance === 'number' ? raw.wallet_balance : Number(raw.wallet_balance || 10),
    hoursTaught: typeof raw.hours_taught === 'number' ? raw.hours_taught : Number(raw.hours_taught || 0),
    hoursLearned: typeof raw.hours_learned === 'number' ? raw.hours_learned : Number(raw.hours_learned || 0),
    peerReputation: typeof raw.peer_reputation === 'number' ? raw.peer_reputation : Number(raw.peer_reputation || 5),
    reviewCount: typeof raw.review_count === 'number' ? raw.review_count : Number(raw.review_count || 0),
    swapFulfillRate:
      typeof raw.swap_fulfill_rate === 'number' ? raw.swap_fulfill_rate : Number(raw.swap_fulfill_rate || 100),
    publicProfileId,
    publicProfileEnabled: true,
    publicLearningHistory: raw.public_learning_history !== false,
    privacy: {
      verifiedPeersOnly: raw.verified_peers_only !== false,
      allowDirectSwaps: raw.allow_direct_swaps !== false,
      publicLearningHistory: raw.public_learning_history !== false,
      maskReviews: raw.mask_reviews === true,
      publicProfileEnabled: true,
    },
    teachingSkills,
    learningSkills,
    badges: [],
    reviews: [],
    journey: [
      {
        id: `m-${raw.id}`,
        title: 'Joined SkillSwap Campus Network',
        description: 'Completed onboarding profile and verified campus credentials.',
        timeAgo: 'Active',
        date: 'Oct 2026',
        type: 'badge',
        creditsChange: 10,
        term: 'Fall Quadrangle 2024',
      },
    ],
  };
}

/**
 * Backup newly registered user into JSON files to maintain backward compatibility
 */
function syncJsonBackup(user: any) {
  const jsonPaths = [
    path.resolve(process.cwd(), 'uploads', 'data', 'users.json'),
    path.resolve(process.cwd(), 'src', 'data', 'registeredUsers.json'),
  ];

  for (const p of jsonPaths) {
    try {
      let list: any[] = [];
      if (fs.existsSync(p)) {
        list = JSON.parse(fs.readFileSync(p, 'utf8'));
      }
      const filtered = list.filter((u) => u.id !== user.id && u.email.toLowerCase() !== user.email.toLowerCase());
      filtered.push(user);
      const dir = path.dirname(p);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(p, JSON.stringify(filtered, null, 2), 'utf8');
    } catch (e) {
      console.warn(`[PostgreSQL] Failed to sync JSON backup to ${p}:`, e);
    }
  }
}

/**
 * Save video upload record to PostgreSQL lesson_videos table
 */
export async function saveLessonVideoRecord(meta: {
  id: string;
  lessonId?: string;
  originalFilename: string;
  mimeType: string;
  fileSize: number;
  duration?: string;
  durationSeconds?: number;
  storageKey: string;
  storageUrl: string;
  uploadedBy?: string;
}): Promise<void> {
  const db = await getDatabase();
  await db.query(
    `INSERT INTO lesson_videos (id, lesson_id, original_filename, mime_type, file_size, duration, duration_seconds, storage_key, storage_url, uploaded_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
     ON CONFLICT (id) DO UPDATE SET
       storage_url = EXCLUDED.storage_url,
       duration = EXCLUDED.duration,
       duration_seconds = EXCLUDED.duration_seconds,
       updated_at = CURRENT_TIMESTAMP`,
    [
      meta.id,
      meta.lessonId || null,
      meta.originalFilename,
      meta.mimeType,
      meta.fileSize,
      meta.duration || '00:00',
      meta.durationSeconds || null,
      meta.storageKey,
      meta.storageUrl,
      meta.uploadedBy || null,
    ]
  );

  if (meta.lessonId) {
    await updateLessonVideoInDb(meta.lessonId, {
      videoUrl: meta.storageUrl,
      videoFileName: meta.originalFilename,
      videoDuration: meta.duration || '00:00',
      videoFileSize: meta.fileSize,
      videoStorageKey: meta.storageKey,
      videoMimeType: meta.mimeType,
    });
  }
}

/**
 * Update lesson video details in PostgreSQL
 */
export async function updateLessonVideoInDb(
  lessonId: string,
  videoInfo: {
    videoUrl: string;
    videoFileName: string;
    videoDuration: string;
    videoFileSize: number;
    videoStorageKey: string;
    videoMimeType?: string;
  }
): Promise<void> {
  const db = await getDatabase();
  await db.query(
    `UPDATE lessons
     SET video_url = $1,
         video_filename = $2,
         video_duration = $3,
         video_file_size = $4,
         video_storage_key = $5,
         video_mime_type = $6,
         updated_at = CURRENT_TIMESTAMP
     WHERE id = $7`,
    [
      videoInfo.videoUrl,
      videoInfo.videoFileName,
      videoInfo.videoDuration,
      videoInfo.videoFileSize,
      videoInfo.videoStorageKey,
      videoInfo.videoMimeType || 'video/mp4',
      lessonId,
    ]
  );
}

/**
 * Get lesson video metadata by storage key from PostgreSQL
 */
export async function getLessonVideoByStorageKey(storageKey: string): Promise<any | null> {
  const db = await getDatabase();
  const res = await db.query('SELECT * FROM lesson_videos WHERE storage_key = $1', [storageKey]);
  return res.rows.length > 0 ? res.rows[0] : null;
}


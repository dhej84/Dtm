import { execFile } from 'child_process';
import util from 'util';

const execFileAsync = util.promisify(execFile);

export const MIN_ALLOWED_VIDEO_SECONDS = 30;
export const MAX_ALLOWED_VIDEO_SECONDS = 90;
// Sub-second tolerance for container timestamp framing (e.g. 29.5s to 90.5s)
export const MIN_DURATION_TOLERANCE_SECONDS = 29.5;
export const MAX_DURATION_TOLERANCE_SECONDS = 90.5;

export interface VideoProbeDetails {
  durationSeconds: number;
  formattedDuration: string;
  width?: number;
  height?: number;
  codec?: string;
  formatName?: string;
}

export interface VideoDurationValidation {
  isValid: boolean;
  durationSeconds: number;
  formattedDuration: string;
  error?: string;
  code?: 'VIDEO_TOO_SHORT' | 'VIDEO_TOO_LONG' | 'INVALID_VIDEO_FILE' | 'UNKNOWN_ERROR';
}

/**
 * Format raw seconds to MM:SS string
 */
export function formatSecondsToMinutes(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const totalSecs = Math.round(seconds);
  const mins = Math.floor(totalSecs / 60);
  const secs = totalSecs % 60;
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

/**
 * Inspect a video file on disk using ffprobe to obtain accurate duration, resolution and codec
 */
export async function probeVideoFile(filePath: string): Promise<VideoProbeDetails> {
  try {
    const { stdout } = await execFileAsync(
      '/usr/bin/ffprobe',
      [
        '-v',
        'error',
        '-show_entries',
        'format=duration,format_name:stream=codec_name,width,height',
        '-of',
        'json',
        filePath,
      ],
      { timeout: 15000 }
    );

    const parsed = JSON.parse(stdout);
    const durationStr = parsed.format?.duration;
    const durSec = parseFloat(durationStr);

    if (isNaN(durSec) || !isFinite(durSec) || durSec <= 0) {
      throw new Error('Unable to extract duration from video stream. File may be corrupted or unencoded.');
    }

    const videoStream = parsed.streams?.find((s: any) => s.codec_name && (s.width || s.height)) || parsed.streams?.[0];

    return {
      durationSeconds: durSec,
      formattedDuration: formatSecondsToMinutes(durSec),
      width: videoStream?.width,
      height: videoStream?.height,
      codec: videoStream?.codec_name,
      formatName: parsed.format?.format_name,
    };
  } catch (err: any) {
    if (err.killed) {
      throw new Error('Video duration probe timed out. The file may be corrupted.');
    }
    throw new Error('Unsupported or corrupted video file. Supported formats: MP4, WebM, MOV.');
  }
}

/**
 * Validate that video duration is strictly within 30 seconds to 90 seconds (1m 30s)
 */
export function validateVideoDuration(durationSeconds: number): VideoDurationValidation {
  const formatted = formatSecondsToMinutes(durationSeconds);

  if (isNaN(durationSeconds) || durationSeconds <= 0) {
    return {
      isValid: false,
      durationSeconds: 0,
      formattedDuration: '00:00',
      code: 'INVALID_VIDEO_FILE',
      error: 'Invalid or missing video duration metadata.',
    };
  }

  if (durationSeconds < MIN_DURATION_TOLERANCE_SECONDS) {
    return {
      isValid: false,
      durationSeconds,
      formattedDuration: formatted,
      code: 'VIDEO_TOO_SHORT',
      error: `Video duration is too short (${formatted}). Video duration must be between 30 seconds and 90 seconds (1 minute 30 seconds).`,
    };
  }

  if (durationSeconds > MAX_DURATION_TOLERANCE_SECONDS) {
    return {
      isValid: false,
      durationSeconds,
      formattedDuration: formatted,
      code: 'VIDEO_TOO_LONG',
      error: `Video duration exceeds limit (${formatted}). Video duration must be between 30 seconds and 90 seconds (1 minute 30 seconds).`,
    };
  }

  return {
    isValid: true,
    durationSeconds,
    formattedDuration: formatted,
  };
}
